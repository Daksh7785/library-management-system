---
name: Lumina Nexus
colors:
  surface: '#fef7ff'
  surface-dim: '#dfd7e6'
  surface-bright: '#fef7ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f9f1ff'
  surface-container: '#f3ebfa'
  surface-container-high: '#ede5f4'
  surface-container-highest: '#e8dfee'
  on-surface: '#1d1a24'
  on-surface-variant: '#4a4455'
  inverse-surface: '#332f39'
  inverse-on-surface: '#f6eefc'
  outline: '#7b7487'
  outline-variant: '#ccc3d8'
  surface-tint: '#732ee4'
  primary: '#630ed4'
  on-primary: '#ffffff'
  primary-container: '#7c3aed'
  on-primary-container: '#ede0ff'
  inverse-primary: '#d2bbff'
  secondary: '#006591'
  on-secondary: '#ffffff'
  secondary-container: '#39b8fd'
  on-secondary-container: '#004666'
  tertiary: '#7d3d00'
  on-tertiary: '#ffffff'
  tertiary-container: '#a15100'
  on-tertiary-container: '#ffe0cd'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#eaddff'
  primary-fixed-dim: '#d2bbff'
  on-primary-fixed: '#25005a'
  on-primary-fixed-variant: '#5a00c6'
  secondary-fixed: '#c9e6ff'
  secondary-fixed-dim: '#89ceff'
  on-secondary-fixed: '#001e2f'
  on-secondary-fixed-variant: '#004c6e'
  tertiary-fixed: '#ffdcc6'
  tertiary-fixed-dim: '#ffb784'
  on-tertiary-fixed: '#301400'
  on-tertiary-fixed-variant: '#713700'
  background: '#fef7ff'
  on-background: '#1d1a24'
  surface-variant: '#e8dfee'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  title-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: '1.5'
    letterSpacing: '0'
  body-base:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: '0'
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 0.5rem
  sm: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  gutter: 1.5rem
  margin: 2rem
---

## Brand & Style

The brand personality is authoritative yet approachable, designed to function as a digital sanctuary for knowledge management. It balances the intellectual heritage of traditional libraries with the efficiency of modern cloud computing. 

The visual style is **Minimalist / Modern Corporate**. It emphasizes clarity through generous white space, a disciplined card-based architecture, and a focused color palette. The UI is designed to reduce cognitive load for librarians and patrons, ensuring that complex data visualizations and extensive book catalogs remain legible and aesthetically pleasing. High-quality iconography and a refined type scale provide the premium feel required for a high-end SaaS platform.

## Colors

The palette uses a deep violet as the primary anchor to signify wisdom and institutional stability. The sky-blue accent is reserved for interactive growth elements, such as "Add New" actions or progress indicators. 

The background strategy utilizes a very light slate for the light mode to reduce eye strain during long sessions, while the dark mode uses a deep navy-slate to maintain high contrast without pure black harshness. Surface colors for cards should be pure white (#FFFFFF) in light mode and a slightly lighter slate (#1E293B) in dark mode to create a clear visual hierarchy.

## Typography

This design system relies exclusively on **Inter** to ensure maximum legibility across dense data tables and long-form book descriptions. The type scale is built on a tight melodic ratio to provide a professional, systematic rhythm.

Headlines should utilize a slightly tighter letter spacing and heavier weights to command attention, while body text maintains a generous line height (1.6) to facilitate scanning of bibliographic data. Labels use a bold, uppercase treatment to distinguish metadata from content.

## Layout & Spacing

The layout follows a **Fixed-Fluid Hybrid** model. While the sidebar navigation remains fixed, the main content area uses a 12-column fluid grid that adapts to the viewport. Spacing is strictly governed by an 8px (0.5rem) baseline grid.

Card containers should be separated by `md` (1.5rem) gutters. Inner card padding is standardized at `md` for content and `sm` for headers to create a nested, organized appearance. Horizontal margins for the main application container should scale with the screen size but never drop below `margin` (2rem) on desktop.

## Elevation & Depth

This design system uses **Ambient Shadows** to create a sense of tactile layering without clutter. 

- **Level 0 (Floor):** The main background color (#F8FAFC).
- **Level 1 (Cards):** Uses a subtle, high-diffusion shadow: `0px 4px 6px -1px rgba(0, 0, 0, 0.05), 0px 2px 4px -1px rgba(0, 0, 0, 0.03)`.
- **Level 2 (Hover/Modals):** Elements that are interactively lifted use a more pronounced shadow: `0px 10px 15px -3px rgba(0, 0, 0, 0.1)`.

In dark mode, depth is primarily conveyed through **Tonal Layers** rather than shadows. Surfaces move from the darkest navy (background) to lighter slates as they "rise" toward the user.

## Shapes

The shape language is defined by **Rounded** geometry to soften the technical nature of the software. 

- **Standard Elements:** Buttons, input fields, and small badges use a `0.5rem` (8px) radius.
- **Large Containers:** Content cards and modals utilize a `1rem` (16px) radius to create a soft framing effect for the information inside.
- **Interactive Indicators:** Elements like active state pills or circular icon backgrounds use a full `9999px` radius.

## Components

### Buttons
- **Primary:** Violet-600 background, white text. Transitions to Violet-700 on hover.
- **Secondary:** Transparent background with a 1px border of Slate-200. Sky-500 text.
- **Danger:** Red-500 background. Use only for destructive actions like "Delete Record."
- **States:** All buttons include a 2px focus ring of Sky-300 when navigated via keyboard.

### Cards
Cards are the primary container for book details and analytics. They must feature a 1px border (Slate-100) and Level 1 elevation. Headers within cards should be separated by a subtle horizontal rule.

### Inputs
Search bars and form fields use a Slate-50 background with a Slate-200 border. On focus, the border transitions to Violet-600 with a subtle glow effect.

### Badges
Used for book status (e.g., "Available," "Overdue").
- **Available:** Success-green background (10% opacity) with solid green text.
- **Overdue:** Error-red background (10% opacity) with solid red text.
- **Reserved:** Sky-blue background (10% opacity) with solid blue text.

### Iconography
Icons should be 24px, linear (2px stroke), with rounded terminals to match the shape language. Use a consistent Slate-500 color for inactive icons and Primary-600 for active states.